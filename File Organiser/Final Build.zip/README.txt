
1. Open program
2. Click blue question mark for instructions